<?php
/* Silence is golden. */
?>